<?php
    include("dbcon.php");
    if (isset($_POST['btnAddComment']))
    {
        $username = $_POST['txtName'];
        $comment = $_POST['txtComment'];

        $query = "insert into tabcomments (username, comment) values('$username', '$comment')";
        mysqli_query($con, $query); 
    }
    if (isset($_POST['btnAddReply']))
    {
        $commentid = $_POST['commentid'];
        $username = $_POST['txtName'];
        $reply = $_POST['txtReply'];

        $query = "insert into tabreplies (commentid, username, reply) values('$commentid', '$username', '$reply')";
        mysqli_query($con, $query); 
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .page
        {
            width:100%;
            height:60px;
            background-color:#12ddff;
        }
        .comment_box
        {
            width:500px;
            padding: 20px;
            background-color:#DDDDDD;
            border:1px #666 solid;
            margin-bottom:10px
        }
        h4, p {
            margin:0px;
        }
        .reply
        {
            margin-left:50px;
            
        }
        .reply p {
            margin-bottom:20px !important;
        }
        textarea{
            height: 20px;
            margin-top:20px !important;
        }
        #a{
            position: relative;
           top: 8px;
           height: 20px;
        }
    </style>
    <script>
        function addreply(commentid)
        {
            reply_box = document.getElementById("replybox" + commentid).innerHTML = '<?php include("reply.php"); ?>';            
        }
    </script>
</head>
<body>
    <div class="page">
        <h1>Comment and Reply Section</h1>
    </div>
    <form method="post">
        <input type="text" name="txtName" placeholder="Enter Your Name" required/>
        <textarea id="a"  name="txtComment" placeholder="Enter Your Comment"></textarea>
        <input id="b" type="submit" name="btnAddComment" value="Add Comment" />
    </form>
    <br />
    <?php 
     $query0 = "SELECT * FROM `tabcomments`";
     $result0 = mysqli_query($con, $query0);
    
    ?>
    <form method="get">
        <input type="text" name="search" list="user_name" required/>
        <datalist id="user_name">
         <?php while($record0 = mysqli_fetch_array($result0)) { ?>
         <option value="<?php echo $record0['username']; ?>"></option>
         <?php } ?>
        </datalist>
        <input type="submit" value="Search"  />        
    </form>
    <form method="get">
    <input type="submit" value="Showall" name="show" />
    
    </form>
    <?php
        if (isset($_GET['search']))
        {
            $search = $_GET['search'];
            $query = "select * from tabcomments where username like '%" .  $search . "%'";
        }
        else 
        {
            $query = "select * from tabcomments";
        }
        $result = mysqli_query($con, $query);
        if (mysqli_num_rows($result) > 0)
        {
            while ($record = mysqli_fetch_array($result)) {
                echo '<div class="comment_box">';
                    echo '<h4>' . $record["username"] . ':</h4>';
                    echo '<p>' . $record["comment"] . '</p>';
                    echo '<a id="lbtReply" onclick="addreply(\'' . $record["commentid"] . '\')" href="#">Reply</a>';
                    echo '<div id="replybox' . $record["commentid"] . '">';

                    echo '</div>';
                    $query2 = "select * from tabreplies where commentid='" . $record['commentid'] . "'";
                    $result2 = mysqli_query($con, $query2);
                    if (mysqli_num_rows($result) > 0)
                    {
                        while($record2 = mysqli_fetch_array($result2))
                        {
                            echo '<div class="reply">';
                            echo '<h4>' . $record2["username"] . ':</h4>';
                            echo '<p>' . $record2["reply"] . '</p>';
                            echo '</div>';
                        }
                    }
                echo '</div>';
            }
        }
        else
        {
            echo "No Comments";
        }
    ?>
</body>
</html>